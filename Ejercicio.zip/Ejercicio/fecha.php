<html>
    <head>
        <title>
            Fecha
        </title>
    </head>
    <body>
        <div>
            <p>
                Bienvenido, aqui tienes la fecha:
            </p>
            <?php
            date_default_timezone_set("UTC");
            echo "Hoy estamos a: ";
            echo date("d F Y");
            ?>
        </div>
    </body>
</html>