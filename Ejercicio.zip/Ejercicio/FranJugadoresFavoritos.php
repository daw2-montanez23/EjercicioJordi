<?php
session_start();

//Check user permission
if ($_SESSION['authuser'] != 1){
    echo "no tienes permisos para ver la pagina";
    exit();     
}
?>
<html>
 <head><title>
<?php
if (isset($_GET["Jugadores"])) {
	echo " - ";
	echo $_GET["Jugadores"];
}
?>
</title></head>
<body>
<?php 

$misjugadoresfavoritos = array(	"Leo Messi",
					"Cristiano Ronaldo",
					"Neymar Jr",
					"Xavi Hernandez",
					"Zidane",
					);

if (isset($_GET["jugador"])) {
	echo "Bienvenido";
} else {
	echo "El top 5 de de mis jugadores favoritos son:";
	if (isset($_GET["jugadores"])) {
		sort($misjugadoresfavoritos);
	}
	echo "<ol>";
	foreach ($misjugadoresfavoritos as $jugador) {
		echo "<li>";
		echo $jugador;
	}
	echo "</ol>";
}
?>
</body>
</html>