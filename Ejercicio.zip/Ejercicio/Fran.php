<?php
session_start();
?>
<html>
    <head>
        <title>
            Hola
        </title>
    </head>
    <body>
        <?php
        include "fecha.php";?>
        <form method="Post" action="FranPaginaPrincipal.php">
        <p>Usuario:
            <input type="text" name="user"/>
        </p>
        <p>Password:
            <input type="password" name="pass"/>
        </p>
        <p>Enviar
            <input type="Submit" name="Submit" value="Enviar">
        </p>
        </form>
        
    </body>
</html>