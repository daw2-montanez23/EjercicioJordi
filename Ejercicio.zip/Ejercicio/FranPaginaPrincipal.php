<?php
session_start();
$_SESSION['username']=$_POST['user'];
$_SESSION['password']=$_POST['pass'];
$_SESSION['authuser']=0;

if(($_SESSION['username']=='Fran') and($_SESSION['password']=='12345')){
    $_SESSION['authuser']=1;
}else{
    echo "Tu quien eres?? ";
    exit();
}
?>
<html>
    <head>
        <title>Pagina Principal</title>
    </head>
    <body>
        <?php
        include "fecha.php";

        echo "<a href='FranJugadoresFavoritos.php'>";
        echo "Haz click para ver mis jugadores favoritos";
        echo "</a>";
        ?>
    </body>
</html>